<template>
  <div class="opption">
    <h1>We have cards:{{cardCount}}</h1>
   <form @submit.prevent="addCardData">
    <div>
      <input type="text" placeholder="frist name" v-model="firstName">
    </div>
    <div>
      <input type="text" placeholder="last name" v-model="lastName">
    </div>
    <div>
      <input type="number" placeholder="age" v-model="age">
    </div>
    <div>
      <button class="button-20 " type="sumbit">Add</button>
    </div>
   </form>
<section>
  <div class="card" v-for="(cardData,index) in cardDatas" :key="index">
      <div class="card-header">
          <h2>{{cardData.firstName}}</h2>
      </div>
    <div class="card-body">
      <h2>{{cardData.lastName}}</h2>
    </div>
    <div class="card-body">
      <span>{{cardData.age}}</span>
    </div>
  <div>
    <button class="button-24 " @click="onDelete(index)">delete</button>
  </div>
  </div>
</section>

  </div>
</template>

<script>
import {ref,computed, watch, reactive} from 'vue'
export default {
setup(){

  let cardDatas=ref([])

  let mydata= reactive({
    firstName:'',
    lastName:'',
    age:'',
    cardDatas:[]
  })
  const licenWord=['Phanith','chhim']

  let cardCount = computed(()=>{
    return  mydata.cardDatas.length
  })

  function addCardData(){
    let cardObject={
      firstName:  mydata.firstName,
      lastName:  mydata.lastName,
      age:  mydata.age
    }
     mydata.cardDatas.push(cardObject)
     mydata.firstName ='',
     mydata.lastName ='',
     mydata.age =''
  }

  function onDelete(index){
     mydata.cardDatas.splice(index,1)
  }
watch( mydata,(newValue)=>{
  console.log('firstName:', newValue)
  if(licenWord.includes(newValue.firstName.toLowerCase())){
    mydata.firstName =''
    alert('This name has no permission !!')
  }
})

return{
  firstName,
  lastName,
  age,
  cardDatas,
  cardCount,
  addCardData,
  onDelete,
  mydata
}
}
}
</script>

<style scoped>


  form{
    width: 100%;

  }
  input{
    margin: 5px;
    width: 400px;
    padding: 10px;
  }
  .card{
    margin: auto;
    width: 50%;
    border-top: 4px solid blue;
    box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
  }
 
.button-24 {
  background: #FF4742;
  border: 1px solid #FF4742;
  border-radius: 6px;
  box-shadow: rgba(0, 0, 0, 0.1) 1px 2px 4px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: nunito,roboto,proxima-nova,"proxima nova",sans-serif;
  font-size: 16px;
  font-weight: 800;
  line-height: 16px;
  min-height: 40px;
  outline: 0;
  padding: 12px 14px;
  text-align: center;
  text-rendering: geometricprecision;
  text-transform: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: middle;
}

.button-24:hover,
.button-24:active {
  background-color: initial;
  background-position: 0 0;
  color: #FF4742;
}

.button-24:active {
  opacity: .5;
}

.button-20 {
  appearance: button;
  background-color: #4D4AE8;
  background-image: linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));
  border: 1px solid #4D4AE8;
  border-radius: 1rem;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset,rgba(46, 54, 80, 0.075) 0 1px 1px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: inline-block;
  font-family: Inter,sans-serif;
  font-size: 1rem;
  font-weight: 500;
  line-height: 1.5;
  margin: 0;
  padding: .5rem 1rem;
  text-align: center;
  text-transform: none;
  transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: middle;
}

.button-20:focus:not(:focus-visible),
.button-20:focus {
  outline: 0;
}

.button-20:hover {
  background-color: #3733E5;
  border-color: #3733E5;
}

.button-20:focus {
  background-color: #413FC5;
  border-color: #3E3BBA;
  box-shadow: rgba(255, 255, 255, 0.15) 0 1px 0 inset, rgba(46, 54, 80, 0.075) 0 1px 1px, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20:active {
  background-color: #3E3BBA;
  background-image: none;
  border-color: #3A38AE;
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset;
}

.button-20:active:focus {
  box-shadow: rgba(46, 54, 80, 0.125) 0 3px 5px inset, rgba(104, 101, 235, 0.5) 0 0 0 .2rem;
}

.button-20:disabled {
  background-image: none;
  box-shadow: none;
  opacity: .65;
  pointer-events: none;
}
</style>



